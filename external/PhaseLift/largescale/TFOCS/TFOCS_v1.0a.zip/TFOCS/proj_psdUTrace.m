function op = proj_psdUTrace( q )

%PROJ_PSDUTRACE   Positive semidefinite cone with fixed trace.
%    OP = PROJ_PSDUTRACE( q ) returns a function that implements the
%    indicator for the cone of positive semidefinite matrices with
%    fixed trace: { X | min(eig(X+X'))>=0, trace(0.5*(X+X'))==q
%    Q is optional; if omitted, Q=1 is assumed. But if Q is supplied, 
%    it must be a positive real scalar.

if nargin == 0,
	q = 1;
elseif ~isnumeric( q ) || ~isreal( q ) || numel( q ) ~= 1 || q <= 0,
	error( 'Argument must be positive.' );
end
q = proj_simplex( q );
%op = @(x,t)proj_psdUTrace_q( q, x, t );
op = @(varargin)proj_psdUTrace_q( q, varargin{:} );

function [ v, X ] = proj_psdUTrace_q( eproj, X, t )

v = 0;
X = 0.5*(X+X');
if nargin > 2 && t > 0,
    [V,D]=eig(X);
    [dum,D] = eproj(diag(D),t);
    tt = D > 0;
    V  = bsxfun(@times,V(:,tt),sqrt(D(tt,:))');
    X  = V * V';
elseif any(eig(X)<0),
    v = Inf;
end

% TFOCS v1.0a by Stephen Becker, Emmanuel Candes, and Michael Grant.
% Copyright 2010 California Institute of Technology and CVX Research.
% See the file TFOCS/COPYING.txt for full license information.

