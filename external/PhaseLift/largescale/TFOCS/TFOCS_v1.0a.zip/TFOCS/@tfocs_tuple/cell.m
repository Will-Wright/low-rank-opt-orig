function v = cell( x )

% CELL  Conversion to a cell array.

v = x.value_;

% TFOCS v1.0a by Stephen Becker, Emmanuel Candes, and Michael Grant.
% Copyright 2010 California Institute of Technology and CVX Research.
% See the file TFOCS/COPYING.txt for full license information.
