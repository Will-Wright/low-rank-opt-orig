function op = prox_nuclear( q )

%PROX_NUCLEAR    Nuclear norm.
%    OP = PROX_NUCLEAR( q ) implements the nonsmooth function
%        OP(X) = q * sum(svd(X)).
%    Q is optional; if omitted, Q=1 is assumed. But if Q is supplied, 
%    it must be a positive real scalar.
%
% This implementation uses a naive approach that does not exploit any
% a priori knowledge that X and G are low rank or sparse. Future
% implementations of TFOCS will be able to handle low-rank matrices 
% more effectively.

if nargin == 0,
	q = 1;
elseif ~isnumeric( q ) || ~isreal( q ) || numel( q ) ~= 1 || q <= 0,
	error( 'Argument must be positive.' );
end
%op = @(x,t)prox_nuclear_impl( q, x, t );
op = @(varargin)prox_nuclear_impl( q, varargin{:} );

% SRB: I think the function was meant to be called _impl
%function [ v, X ] = prox_nuclear_q( q, X, t )
function [ v, X ] = prox_nuclear_impl( q, X, t )
if nargin > 2 && t > 0,
    [U,S,V] = svd( X, 'econ' );
    s  = diag(S) - q * t;
    tt = s > 0;
    s  = s(tt,:);
    if isempty(s),
        X(:) = 0;
    else
        X = U(:,tt) * bsxfun( @times, s, V(:,tt)' );
    end
else
    s = svd(X);
end
v = q * sum(s);

% TFOCS v1.0a by Stephen Becker, Emmanuel Candes, and Michael Grant.
% Copyright 2010 California Institute of Technology and CVX Research.
% See the file TFOCS/COPYING.txt for full license information.
