function [ x, odata, optsOut ] = continuation( fcn, mu, x0, z0, opts, contOpts )
error(nargchk(2,6,nargin));
if nargin < 3, x0   = []; end
if nargin < 4, z0   = []; end
if nargin < 5, opts = []; end
if nargin < 6, contOpts = []; end

kMax    = setOpts('maxIts',3);
ACCEL   = setOpts('accel',true);
betaTol = setOpts('betaTol',2);
stopTol = setOpts('tol',1e-3);
% not for release yet

% what is the user specified stopping tolerance?
if ~isfield(opts,'tol')
    % get the default value:
    defaultOpts = solver_SCD();
    opts.tol = defaultOpts.tol;
end
finalTol    = opts.tol;
tol         = finalTol*betaTol^(kMax+1);

xOld = x0;
for k = 1:kMax
    if kMax > 1
        fprintf('---- Continuation step %d of %d ----\n', k, kMax );
    end
    
    tol         = tol/betaTol;
    opts.tol    = tol;
    [x, odata, optsOut ] = fcn( mu, x0, z0, opts );
    if k == kMax, break; end
    if isempty(xOld), xOld = x; end
    if ACCEL
        x0 = x + k/(k+3)*( x - xOld );
    end
    xOld = x;
    if isa( odata.dual, 'tfocs_tuple')
        z0 = cell( odata.dual );
    else
        z0 = odata.dual;
    end

    if norm(x0 - xOld)/norm(xOld) <= stopTol
        break;
    end
end


function out = setOpts(fieldName,default)
    if ~isfield(contOpts,fieldName)
        contOpts.(fieldName) = default;
    end
    out = contOpts.(fieldName);
end


end

% TFOCS v1.0a by Stephen Becker, Emmanuel Candes, and Michael Grant.
% Copyright 2010 California Institute of Technology and CVX Research.
% See the file TFOCS/COPYING.txt for full license information.



