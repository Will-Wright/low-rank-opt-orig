%{
    Tests nuclear norm minimization,

    min_X ||X||_*
s.t.
    ||P(X) - b||_2 <= eps  (or P(X) == b)

where X is a M x N matrix, and P is an observation operator

The solvers solve a regularized version, using
||X||_* + mu/2*||X-X_0||_F^2
and you can either decrease the value of mu,
or use continuation (e.g. accelerated continuation)
to get the solution to the un-regularized problem.

Note: accelerated continuation works very well for matrix completion because with mu
large, the iterates stay very low-rank.

This file meant for debugging and testing your installation.

There are two "modes":
(1) smallscale.  The SVD is computed with a dense O(n^3) algorithm
(2) largescale.  The SVD is computed using a Lanczos-based method, using the PROPACK software.

Stephen Becker, July 2010, srbecker@caltech.edu


Note: we do not use the "linear" function because it is not necessary

TFOCS ver

%}
base = '~/Dropbox';
if ~exist('runOnce_matrix','var') || ~runOnce_matrix
    addpath( fullfile(base,'CNest') );
    addpath( fullfile(base,'CNest','utilities') );
    addpath( fullfile(base,'CNest','examples','nuclear') );
    addpath( fullfile(base,'CNest','examples','nuclear','utilities') );
    runOnce_matrix = true;
end

%%

randn('state',sum('NuclearNorm'));
rand('state',sum('NuclearNorm2'));
CORRUPTION = false;

M = 1000; N = 1000; R = 10;  % used in the paper (Fig. 9)
% M = 500; N = 500; R = 10;

% M = 80; N = 90; R = 4;
% M = 35; N = 30; R = 4;
% M = 40; N = 50; R = 3; % leads to gradient descent outpeforming Nesterov
% M = 30; N = 30; R = 2;
df = R*(M+N-R);
oversample = 5;
Left  = randn(M,R);
Right = randn(N,R);
k = round(oversample*df); k = min( k, round(.8*M*N) );
omega = randperm(M*N);
omega = sort(omega(1:k)).';
p = k/(M*N);
fprintf('%d x %d rank %d matrix, observe %d = %.1f x df = %.1f%% entries\n',...
    M,N,R,k,k/df,p*100);
[omegaI,omegaJ] = ind2sub([M,N],omega);
mat = @(x) reshape(x,M,N);
vec = @(x) x(:);
if ~issorted(omega)
    error('Algorithm assumes omega is sorted, for simplicity');
end

% for very large matrices, it's time consuming to check ||X-X_exact||_F,
% so randomly sample this
% if M*N > 300^2
if M*N > 1000^2
    disp('Matrix is rather large, so randomly sampling the error');
    omega_test = randperm(M*N);
    omega_test = sort(omega_test(1:min(M*N,300^2)) );
else
    omega_test = 1:(M*N);
end
omega_test = omega_test(:); % make it a column vector

if M*N > 2000^2
    disp('Matrix is very large, so not forming it explicitly');
    X_exact = [];
    b_exact = XonOmegaTranspose(Left',Right',omega);
    X_exact_test = XonOmegaTranspose(Left',Right',omega_test);
else
    X_exact = Left*Right';
    b_exact = X_exact(omega);  % no noise for now
    X_exact_test = X_exact( omega_test );
end
normX_exact_test = norm(X_exact_test);

EPS = 0;
b = b_exact;  % noi noise

normX_exact = norm(X_exact,'fro');
er1 = @(X) norm( X_exact-X,'fro')/normX_exact;
er2 = @(X) norm( X(omega)-b)/norm(b);

% simplest guess: the matrix that agrees with observations,
%   and is zero everywhere else:
Xguess = sparse(omegaI,omegaJ,b,M,N);

% mu = .1;
% Pick mu so that ||Xplug||_* is alpha times as large as mu/2||Xplug||^2
%alpha = 100;
%mu = 2*norm_nuc(full(Xguess))/norm(Xguess,'fro')/alpha;
%mu = 0;

% Xplug = zeros(M,N);
Xplug = Xguess;
s = svd(X_exact,'econ');
% obj_optimal = sum(s) + mu/2*norm(s)^2; % true of Xplug is all zero
%obj_optimal = sum(s) + mu/2*norm( X_exact - Xplug ,'fro')^2;  % not used; also, mu not set yet

if M*N < 50*50
    CVX = true;
    % get reference via CVX
    if EPS
      cvx_begin
        variable Xcvx(M,N)
        minimize norm_nuc(Xcvx) %+ mu/2*sum_square( Xcvx(:) - Xplug(:) )
        subject to
            norm(Xcvx(omega) - b ) <= EPS
	  cvx_end
    else
      cvx_begin
        variable Xcvx(M,N)
        minimize norm_nuc(Xcvx) %+ mu/2*sum_square( Xcvx(:) - Xplug(:) )
        subject to
            Xcvx(omega) == b
	  cvx_end
    end
    fprintf('Error with cvx is %.2e\n', er1(Xcvx) );
    normXcvx = norm(Xcvx,'fro');
else
    CVX = false;
%     Xcvx = X_exact;
    Xcvx = [];
%     normXcvx = norm(Xcvx,'fro');
    normXcvx = [];
end

%% set some parameters

Xplug = zeros(M,N); normXplug = 0;
XplugF = Xplug;
% normXplug = norm(Xplug,'fro')^2;
% lambda0 = zeros(size(b));
% lambda0 = b;
L = 1;  % bound on Lipschitz constant
% m = sqrt(p);  % estimate of "strong convexity constant" (not rigorous)

optsBase = [];
optsBase.maxits     = 500;      % Fig 9 in the paper used 500
% optsBase.maxits     = 25; disp('Warning: using very low maxits'); % for testing
optsBase.maxmin     = -1;        % tell it to do maximization of dual
optsBase.saddle     = 1;
optsBase.printEvery = 10;
optsBase.dualAvg = false;  % since we use packed storage
optsBase.L          = L;
% optsBase.L          = p/1.2; % SVT convention
optsBase.errFcn     = {@(f,x)error(x), @(f,x) f-fStar};
optsBase.solver     = @solver_AT;
optsBase.tol        = 0;


%--  Setup tests --
% To add a test to the list, just uncomment out the relevant section

testOptions = {};

% opts = optsBase; % this one is not used in Fig 9 in the paper
% opts.name   = 'GRA, t=1/L';
% opts.L      = L;
% opts.Lexact = L;
% opts.constantStepSize = true;
% opts.solver = @solver_GradientDescent;
% testOptions{end+1} = opts;

% opts = optsBase; % this one is not used in Fig 9 in the paper
% opts.name   = 'GRA, t=p/1.2';
% opts.L      = p/1.2;
% opts.Lexact = p/1.2;
% opts.constantStepSize = true;
% opts.solver = @solver_GradientDescent;
% testOptions{end+1} = opts;


opts = optsBase;
opts.name   = 'GRA, backtracking';
opts.L      = L;
opts.solver = @solver_GradientDescent;
testOptions{end+1} = opts;

% opts = optsBase; % this one is not used in Fig 9 in the paper
% opts.name   = 'AT, t=1/L';
% opts.L      = L;
% opts.Lexact = L;
% opts.constantStepSize = true;
% opts.solver = @solver_AT;
% testOptions{end+1} = opts;

opts = optsBase;
opts.name   = 'AT, backtracking';
opts.L      = L;
opts.solver = @solver_AT;
testOptions{end+1} = opts;

% opts = optsBase;      % this one is not used in Fig 9 in the paper
% opts.name   = 'AT, restart every 5';
% opts.L      = L;
% opts.solver = @solver_AT;
% opts.restart = 5;
% testOptions{end+1} = opts;

opts = optsBase;
opts.name   = 'AT, restart every 10';
opts.L      = L;
opts.solver = @solver_AT;
opts.restart = 10;
testOptions{end+1} = opts;

opts = optsBase;
opts.name   = 'AT, restart every 50';
opts.L      = L;
opts.solver = @solver_AT;
opts.restart = 50;
testOptions{end+1} = opts;

opts = optsBase;
opts.name   = 'AT, restart every 100';
opts.L      = L;
opts.solver = @solver_AT;
opts.restart = 100;
testOptions{end+1} = opts;

%%
% mu = .001;
mu = .0001; % use mu = 1e-4 in Fig. 9 in the paper
testErrors      = {};
times           = [];
shrinkageCalls  = [];
Y = sparse(omegaI,omegaJ,b,M,N); % be careful: this is modified in place
% kicking:
nY = linop_normest(Y,'R2R',1e-4,300);
lambda0 = b/mu/nY;

for test_i = 1:length( testOptions )
    opts = testOptions{test_i};
    solver = opts.solver;
    lambda = lambda0;
    ERR = [];
    k_end = 1;
    if isfield(opts,'restart') 
        k_end = round( opts.maxits / opts.restart );
        opts.maxits = opts.restart;
    end
    shrinkMatrix();  % zero it out
    tic
    for k = 1:k_end
        
        % all of these error functions may be slow to calculate
        if CVX
            opts.errFcn        = { @(l,f,x) norm(unpackSVD(x)-Xcvx)/normXcvx };
        else
            opts.errFcn        = { @(l,f,x) norm(samplePackedMatrix(x,omega_test)...
                -X_exact_test)/normX_exact_test };
        end
        
        % this operates on a packed matrix
        if norm(normXplug,'fro') < 10*eps
            obj = @(x) sum(unpackSVD(x,'s')) + mu/2*norm(unpackSVD(x,'s'))^2;
            objExact = obj(packSVD(Xcvx));
            opts.errFcn{end+1} = @(l,f,x) obj(x); % smooth_nuclear computes it more efficiently
        else
            % Warning: this may be slow to compute
            %         obj = @(x) sum(unpackSVD(x,'s')) + mu/2*norm( vec(unpackSVD(x)) - Xplug(:) )^2;
            %         opts.errFcn{end+1} = @(l,f,x) obj(x);
        end
        
        rank = @(x) unpackSVD(x,'rank');
        opts.errFcn{end+1} = @(l,f,x) rank(x);
        
        observations = @(X) X(omega);
        opts.errFcn{end+1} = @(l,f,x) (norm( observations(unpackSVD(x)) - b )- EPS)/norm(b); % residual
        
        % For both, use this:
        Y = sparse(omegaI,omegaJ,b,M,N); % be careful: this is modified in place
        linear = [];
        smooth = @(varargin) smooth_nuclear(Y,b,mu,XplugF, varargin{:} );
        proj   = @(varargin) nonsmooth_nuclear(EPS,varargin{:}); % Psi.  Same as for BPDN!
        
        
        [lambda,out,optsOut] = solver( smooth, linear, proj, lambda, opts );
        x = out.dual;
        [U,S,V] = unpackSVD(x);
        s = diag(S);
        X = U*S*V';
        
        ERR = [ERR; out.err ];
    end
    t=toc
    testErrors{end+1} = ERR;
    times   = [times;t];
    sc      = shrinkMatrix();
    shrinkageCalls = [shrinkageCalls; sc ]; % a more fair comparison than just the # of iterations

end
%% sample plot
figure(1);
semilogy( ERR(:,1) )

hold all

%% nice plot with all the experiments
% We can choose to plot vs. # iterations or vs. # shrinkage calls (aka
% SoftThresholdSingVal )
plotIter = false;  % whether to plot vs. # iterations or not

% can also choose whether to plot the estimated error rates
plotRates = false;


figure(2);
clf;
handles = []; rates = [];
legendString = {};
iter = 1:optsBase.maxits;
for test_i = 1:length( testOptions )
    er=testErrors{test_i}(:,1);
    er_rank=testErrors{test_i}(:,3); % for rank
    if any(er_rank>R), disp('found ranks > true rank'); end
    nn = length(er);
    if plotIter
        xGrid = 1:nn;
    else
        xGrid = linspace(1,shrinkageCalls(test_i),nn);
    end
    h=semilogy( xGrid, er ,'linewidth',2);
    hold all
    legendString{end+1} = testOptions{test_i}.name;
    handles= [handles,h];
    
%     r_est = 1-mean( er(2:end)./er(1:end-1) );
    er = er( er > 1e-13) ;
    er = er( er < .5 );
    if ~isempty(er) && er(1) ~= 0
        r_est = 1 - (er(end)/er(1))^(1/length(er));
    else
        r_est = 1;
    end
    rates = [rates;r_est];
    
    if plotRates
        gtext( sprintf('%.4f',r_est), 'fontsize', 16 );
    end
end

legend( handles, legendString,'fontsize',20 ,'location','southwest');

if plotIter
    xlabel('iterations','fontsize',16);
else
    xlabel('calls to SoftThresholdSingVal','fontsize',16);
end
ylabel('error','fontsize',16);
%% if we were strongly convex...
% for gradient descent with stepsize 1/L, r = (L-m)/(L+m) ~ 1 - 2*m/L
r = 1-rates(1);
% m_est = (1-r)*L/2;
m_est = L*(1-r)/(1+r);

optK = @(L,mu) exp(1)*sqrt( 2*L/mu );

KK = optK(L,m_est);
%%
title(sprintf('M=%d, N=%d, p=%.1f%%, d.o.f. = %.f%%, R=%d, \\mu=%.2e, L=1',M,N,100*p,100*df/(M*N),R,mu) );
