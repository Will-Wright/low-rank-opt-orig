%{
Wed, March 17 2010
Stephen Becker

We assume that we can solve a smoothed problem like
min f(x) + mu/2||x-c||^2  s.t. x \in C
for any point c, and f convex, C convex
[ in particular, we'll test the case f(x) = ||x||_1
  and C = { x : ||Ax-b||_2 <= eps }  ]

Now, we'd like to do continuation so that we can eliminate the influence
of the mu/2||x-c||^2 term.

Normal continuation takes mu --> 0.  But keep mu > 0 fixed,
and let c be changed.  What can we say?

Here are two algorithms:

Proximal Point continuation

    c = x_{k-1}
    x_k = argmin_{x \in C} f(x) + mu/2||x-c||^2 

and a new algorithm which I call Accelerated Proximal Point continuation

    c = x_{k-1} + k/(k+3)( x_{k-1} - x_{k-2} )  (standard Nesterov idea)
    x_k = argmin_{x \in C} f(x) + mu/2||x-c||^2 

You can solve the subproblem with either CVX or with TFOCS
(it makes no observable difference).
The reference solution (i.e. to the unsmoothed problem)
is found using CVX.

TFOCS ver

%}

% SOLVER = 'CVX';
SOLVER = 'TFOCS';

if strcmpi(SOLVER,'TFOCS')
    % add the paths
    global TFOCS_base_global
    if isempty( TFOCS_base_global )
        error('PLEASE RUN setup_TFOCS_path FIRST');
    end
    % for the file "solve_Dantzig":
    addpath( fullfile( TFOCS_base_global, 'examples', 'BasisPursuit') );
end
%%

% -- Setup a problem
randn('state',2010);
N       = 200;
M       = 80;
A       = randn(M,N);
xExact  = randn(N,1);
b       = A*xExact;
% epsilon = .01;
epsilon = 1;
% -- Find a reference solution (i.e. unregularized)
cvx_begin
    cvx_quiet(true)
    cvx_precision best
    variable x(N,1)
    minimize norm(x,1)
    subject to
        norm(A*x - b) <= epsilon
cvx_end
if ~strcmpi(cvx_status,'Solved')
    fprintf('\n\nError with CVX answer\n\n');
end
x_ref = x;
er =  @(x) norm(x-x_ref)/norm(x_ref);
er2 = @(x) norm(x,1) - norm(x_ref,1);

% -- Repeatedly solve a smoothed problem
% mu      = .05;  kMax = 25; % convergence is VERY fast when mu is small
mu =  .5; kMax = 30;
% mu      = 5; kMax = 40;
% kMax    = 20;
t       = clock;
% c0      = zeros(N,1);
c0      = randn(N,1);
for NESTEROV = 0:1
    if NESTEROV
        disp('--- Continuation (accelerated) ---');
    else
        disp('--- Continuation (regular) ---');
    end
    
    c       = c0; 
    x0      = zeros(N,1);
    x       = x0;
    xOld    = x;
    data    = [];
    for k = 1:kMax
        
        if NESTEROV==1 % can we accelerate 1/k to 1/k^2?
            c = x + k/(k+3)*(x-xOld);
            xOld = x;
        else
            c = x;
        end
        
        if strcmpi(SOLVER,'CVX')
            precisions = {'best','high','default','medium','low'};
            prec_i = 0;
            cvx_status='';
            while ~strcmpi(cvx_status,'Solved') && prec_i <= 4
                prec_i = prec_i + 1;  % lower the precision if not solved well last time
                cvx_begin
                cvx_quiet(true)
                cvx_precision( precisions{prec_i} )
                variable x(N,1)
                minimize norm(x,1) + mu/2*sum_square(x-c)
                subject to
                norm( A*x - b ) <= epsilon
                cvx_end
            end
            if prec_i > 1, fprintf('\b (solved to precision %s)\n',precisions{prec_i} ); end
        else
            % use TFOCS solver
            opts        = [];
            opts.tol    = 1e-10;
            opts.maxits = 5000;
            opts.x0     = c;
            x = solve_BPDN(A,b,mu,epsilon,opts);
            % it would be more efficient to use the old dual variable
            % to seed the new one, but we're not worried about efficiency
            % here...
        end
        fprintf('Iteration %2d, error is %.2e, ||resid|| is %.2e, ||x||_1-||x^*||_1 is %.2e\n',...
            k, er(x), norm(A*x-b), er2(x) );
        
        % record:
        data(k).er = er(x);
        data(k).er2 = er2(x);
        data(k).resid = norm(A*x-b);
        
    end
    DATA{NESTEROV+1} = data;
end
fprintf('Finished at %s, total wall time is %.2f minutes\n',datestr(now),...
    etime(clock,t)/60 );
%% Plot results
K = 1:kMax;
figure(1); clf;
% plotf = @loglog;
plotf = @semilogy;

data = DATA{1};
plotf( K, ( [data.er]/data(1).er ).^2,'o-','linewidth',2 )
hold all
data = DATA{2};
plotf( K, ( [data.er]/data(1).er ).^2,'*-','linewidth',2 )

h = legend('Regular continuation (fixed \mu)','Accelerated continuation (fixed \mu)',...\
    'location','southwest');
set(h,'fontsize',22);

if strcmpi( get(gca,'XScale'), 'linear' )
    xlim( [1,kMax] );
else
    xlim( [1,2*kMax] );  % for x on log scale
end

xlabel('outer iteration','fontsize',18)
ylabel('error','fontsize',18)

% print it to a PDF using my custom print script:
% print2PDF('AcceleratedContinuation_mu0-5',[],[],[],false);