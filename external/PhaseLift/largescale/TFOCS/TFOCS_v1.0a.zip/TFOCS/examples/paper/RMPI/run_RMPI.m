%{
    Example of the Random Modulator Pre-Integrator (RMPI)
    with a radar pulse and continuous wave interferer

    This was used to generate figures in the paper

%}
%% Setup the path
base = '~/Dropbox';
if ~exist('runOnce','var') || ~runOnce
    addpath( fullfile(base,'CNest') );
    addpath( fullfile(base,'CNest','examples','BasisPursuitAnalysis') );
    addpath( fullfile(base,'CNest','examples','BasisPursuitAnalysis','Gabor') );
    addpath( fullfile(base,'CNest','examples','DantzigAnalysis') );
    %addpath( fullfile(base,'CNest','utilities') ); % necessary?
    runOnce = true;
end
%addpath ~/Documents/MATLAB/CNest/analysis/Gabor/
%addpath ~/Documents/MATLAB/CNest/dantzig_analysis/
%%
factor = 4;
N   = factor*2048;
FS  = 5e9;  % Nyquist rate
BW  = FS/2; % bandwidth if we sampled at Nyquist rate
dT  = 1/FS;
KHz = 1e3; MHz = 1e6; GHz = 1e9; ms = 1e-6; ns = 1e-9; ps = 1e-12;
T   = N*dT;
t   = (0:N-1)*dT;


randn('state',324324); rand('state',324234);
% Add a continuous wave interferer
f1  = rand*BW;  % frequency
a1  = 1;        % amplitude
p1  = rand*2*pi;% phase
% window by a trapezoidal window
tArrive = factor*40*ns;
tRise   = factor*20*ns;  tFall = tRise; 
tDur    = factor*300*ns;
% tRep    = 250*ns;
tRep    = 0;
% get a trapezoidal window:
envelope1 = pulseTrain( t, tArrive, -tRise, tDur, tFall, tRep );
% this is unrealistic, so smooth it a bit:
f_cutoff = .004*FS;  % location of the first zero in frequency
n = find( t < 2/2/f_cutoff ); n = n(end);
kernel = ones(n,1); kernel = kernel / sum(kernel);
envelope1 = conv( envelope1, kernel, 'same' )';
x1  = a1*envelope1.*(sin(2*pi*f1*t + p1 ))';  % signal

% Add a small pulse
f2  = rand*BW;
a2  = 1e-3*a1;
p2  = rand*2*pi;
s   = a2*sin(2*pi*f2*t + p2);
% window by a trapezoidal window
% tArrive = factor*140*ns;
% tRise   = factor*20*ns;  tFall = tRise; 
% tDur    = factor*100*ns;
% Aug 20 2010, changing the above numbers a bit:
tArrive = factor*45*ns;
tRise   = factor*20*ns;  tFall = tRise; 
tDur    = factor*300*ns;

% tRep    = 250*ns;
tRep    = 0;
% get a trapezoidal window:
envelope2 = pulseTrain( t, tArrive, -tRise, tDur, tFall, tRep );
% this is unrealistic, so smooth it a bit:
f_cutoff = .004*FS;  % location of the first zero in frequency
n = find( t < 2/2/f_cutoff ); n = n(end);
kernel = ones(n,1); kernel = kernel / sum(kernel);
envelope2 = conv( envelope2, kernel, 'same' )';

x2 = envelope2.*s';

% x = envelope1;
% x = (x1 + x2)';
x_exact = (x1 + x2);
%
figure(1); clf;
% subplot(2,1,1);
% % [xDemod,phase_estimate] = myDemod( x, f1, dT, 1000*MHz );
% [xDemod,phase_estimate] = myDemod( x, f2, dT, 1000*MHz,p2 );
xDemod = a1*envelope1;
plot( t/ns, xDemod,'linewidth',2 );
hold all
xDemod = 100*a2*envelope2;
plot( t/ns, xDemod,'linewidth',2 );
xlabel('time in ns','fontsize',20);
ylabel('amplitude of envelope','fontsize',20);

h = legend('large pulse','small pulse, scale exaggerated by 100');
set(h,'fontsize',20);
ylim([-.1,1.1])

% 
% subplot(2,1,2);
% win = hamming(N);
% win = blackman(N);
% win = flattopwin(N);
% win = chebwin(N);
% win = blackmanharris(N);
% periodogram( x, win, [], FS );


%% measurements
randn('state',320424); rand('state',3247825);
F_ADC       = 50*MHz;
nChannels   = 8;    % so, equivalent to a 400 MHz sampler
nSamples    = round(FS/F_ADC);
nPeriods    = floor( N/nSamples);
M           = nPeriods*nChannels;
Phi         = zeros(M,N);
for j = 0:nPeriods-1
    Phi(   j*nChannels + (1:nChannels) , j*nSamples + (1:nSamples)  ) = ...
        randsrc(nChannels,nSamples);
end
% add a bit to the final period
Phi( j*nChannels + (1:nChannels), nPeriods*nSamples:N ) = ...
    randsrc( nChannels, N - nPeriods*nSamples+1 );
normA2  = norm(Phi*Phi');
Phi = Phi/sqrt(normA2);

A   = @(x) Phi*x;
At  = @(y) Phi'*y;
b_exact = A(x_exact);
% SNR = 30;   % in dB
x_noisy = awgn(x_exact, 60, 'measured' );
z = x_exact - x_noisy;
b       = A(x_noisy);
% b   = awgn(b_exact, 40, 'measured' );
% z = b-b_exact;
EPS = norm(b-b_exact);
normA2  = norm(Phi*Phi');
fprintf('EPS is %.3f\n', EPS )

win = hamming(N);
clf; periodogram( x_noisy,win, [], FS );

rms = @(x) norm(x)/sqrt(length(x));
snr = @(sig,noise) 20*log10( rms(sig)/rms(noise) );

fprintf('SNR of signal is %.1f dB; SNR of big tone is %.1f dB; SNR of small tone is %.1f dB\n',...
    snr(x_exact,z), snr(x1,z), snr(x2,z) );

sigma = std( b - b_exact );
% when 3/2 duration ratio, get:
% SNR of signal is 60.1 dB; SNR of big tone is 60.1 dB; SNR of small tone is -1.6 dB
% when 3/3 duration ratio, get:
% SNR of signal is 60.1 dB; SNR of big tone is 60.1 dB; SNR of small tone is 0.1 dB
%% for Dantzig, need to find D and delta
DANTZIG = false;
% if DANTZIG
% %     alpha   = .05; % Problem will be feasible 100*(1-alpha) percent of
% %     the time
%     alpha   = .05;
%     Anorms  = sqrt(sum(Phi.^2))';
%     nTrials = min(4*N,400);
%     w       = randn(M,nTrials);
%     supAtz  = sort(max(At(w) ./Anorms(:,ones(1,nTrials))));
%     thresh  = supAtz(round(nTrials*(1-alpha)));  % empirical
%     normA2  = norm(Phi*Phi');
%     if all(delta > 1e-10)
%         delta0  = mean(delta)/normA2;
%         D       = delta0./delta; % watch out for division by 0
%     else
%         D       = 1;
%         delta0  = 0;
%     end
%     % this is VERY slow:
% %     normA2 = norm( diag(D)*(Phi'*Phi) )^2;
%     % better:
%     normA2 = norm(D,Inf)^2;
%     clear alpha w thresh nTrials
% end
% %% alternative way to estimate z
if DANTZIG
    alpha   = .05;
    AtA     = Phi'*Phi;
    Anorms  = sqrt( sum(AtA.^2) )';
    nTrials = min(4*N,400);
    w       = randn(N,nTrials);
    Aw      = Phi'*( Phi*w);
    supAtz  = sort(max(Aw ./Anorms(:,ones(1,nTrials))));
    thresh  = supAtz(round(nTrials*(1-alpha)));  % empirical
    sigma   = std( x_exact - x_noisy);
    delta   = thresh*sigma*Anorms;  % a vector, for Dantzig solvers
    normA2  = norm(Phi*Phi');
    if all(delta > 1e-10)
        delta0  = mean(delta)/normA2;
        D       = delta0./delta; % watch out for division by 0
    else
        D       = 1;
        delta0  = 0;
    end
    normA2 = norm(D,Inf)^2;
    clear alpha w thresh nTrials
end

%% setup dictionary
% The PsiWFF and PsiTransposeWFF code is a Gabor frame
% (i.e. a short-time Fourier transform)
% written by Peter Stobbe
% 
% PsiWFF is the synthesis operator, and acts on coefficients
% PsiTransposeWFF is the analysis operator, and acts on signals
gMax = 0;
gLevels = 5;
tRedundancy = 1;
fRedundancy = 1;
% fRedundancy = 4;
gWindow = 'isine';

lString = {};
figure(2); clf;
% for fRedundancy = 0:3
% for tRedundancy = 0:2
% for gLevels = 0:7

gabor.gMax = gMax; gabor.gLevels = gLevels;
gabor.tRedundancy = tRedundancy; gabor.fRedundancy = fRedundancy;
param.gabor = gabor;

logN = log2(N);
psi_A = @(y) PsiWFF(y,gWindow,logN,logN-gLevels,logN+gMax,tRedundancy,fRedundancy);
psiT_A = @(x) PsiTransposeWFF(x,gWindow,logN,logN-gLevels,logN+gMax,tRedundancy,fRedundancy);

N_Gabor = length( psiT_A( ones(N,1) ) );
param.N_Gabor = N_Gabor;

psi = @(y) counter( psi_A, y);
psiT= @(x) counter( psiT_A,x);

x  = x_exact;
y  = psiT(x);
x2 = psi(y);
d  = length(y);
% The frame is tight, so the psuedo-inverse is just the transpose:
fprintf('Error in PSI(PSI^* x ) - x is %e; N = %d, d = %d, d/N = %.1f\n', ...
    norm(x-x2),N,d,d/N);

normW2 = 1;

% look at coefficients
fcn = @(x) sort(abs(x),'descend');
c = fcn( psiT(x) );
figure(2); 
%clf;
semilogy(c)
hold all

% estimate a power-law decay rate, x_{k} = a*k^p
% offset = round(.2*d);
offset = 1;
cBulk = c( offset:round(.9*d) );
K = length(cBulk);
k = (1:K);
a = [ones(K,1), log(1:K)'] \ log(cBulk);
p = a(2);
% hold all
% semilogy( offset-1+ k, exp(a(1))*k.^p );
lString{end+1} = sprintf('p = %.3f',p );
fprintf('  and p is %.3f\n', p );

% end
legend(lString)


%% RECONSTRUCT via dual conic smoothing
W  = psiT;
Wt = psi;
opts        = [];
opts.maxits = 2500;
opts.maxmin = -1;
opts.saddle = 1;
opts.printEvery = 150;
opts.tol    = 1e-1;
opts.errFcn = { @(l,f,x) norm(x-x_exact)/norm(x_exact) };
if DANTZIG
%     delta = delta0;
    delta = 0.5*delta0;
    % 2.84e-3 rel l2 error, 6.4e-3 lInf error, with 1.0*delta0
    % 2.85e-3 rel l2 error, 8.8e-3 lInf error, with 1.1*delta0
    % 2.60e-3 rel l2 error, 6.1e-3 lInf error, with 0.9*delta0
    % 2.23e-3 rel l2 error, 5.8e-3 lInf error, with 0.8*delta0
    % 1.98e-3, 5.0e-3, .7*delta0
    % 1.54e-3, 3.7e-3, .5*delta0
    opts.errFcn{end+1} = @(l,f,x) norm(D.*(At(A(x)-b)),Inf)-delta;
else
    opts.errFcn{end+1} = @(l,f,x) norm(A(x)-b)-EPS;
end

solver  = @solver_AT;
xx      = Phi\b;
alpha   = norm( W(xx), 1 );
beta    = norm( xx )^2/2;
mu      = .1*(alpha/beta);

%     opts.L      = 2/mu*[ normA2*ones(m,1); normW2*nes(d,1) ];
%     opts.L      = 2/mu*max( normA2, normW2 );
scaleW  = sqrt(normA2/normW2);
MU      = scaleW*mu;
opts.L  = 2/MU*normA2;
% opts.Lexact  = 2/MU*normA2;

if DANTZIG
    lambda0 = zeros(N+d,1);
    proj   = @(varargin) nonsmooth_Dantzig_analysis([N,d],delta, varargin{:} ); 
else
    lambda0 = zeros(M+d,1);
    proj   = @(varargin) nonsmooth_BPDN_analysis([M,N],EPS,varargin{:}); % Psi
end

% xPlug   = Phi\b;
xPlug   = zeros(N,1);
xOld    = xPlug;
xOld_rw = xOld;

% reweighting loop
n_rw = 8;
time=[]; errs = []; iters = [];
% tol_rw              = 1e-4;
% tol_continuation    = 1e-3;

% Here are the relevant parameters
tol_rw              = 1e-2;
tol_continuation    = 1e-3;
% tol_continuation    = 5e-4;
cutoff_rw           = 95;  % of 100
tol_increase        = 1.5;


tt = clock;
for rw = 1:n_rw

    if DANTZIG
        linear = @(varargin) linear_Dantzig_analysis(A,At,@(x)scaleW*W(x),@(x)scaleW*Wt(x),b, D,varargin{:} );
    else
        linear = @(varargin) linear_BP_analysis(A,At,@(x)scaleW*W(x),@(x)scaleW*Wt(x),b,varargin{:} );
    end
    fprintf('\n-- Reweighting %d of %d --\n\n', rw, n_rw );

    % continuation loop
    opts.tol    = 1e-1;
    k_end = 12; % before was 8
    for k = 1:k_end
        if DANTZIG
            smooth = @(varargin) smooth_Dantzig_analysis(mu, xPlug, varargin{:} );
        else
            smooth = @(varargin) smooth_BP_analysis(MU, xPlug, varargin{:} );
        end
        tic;
        [lambda,out,optsOut] = solver( smooth, linear, proj, lambda0, opts );
        time(rw,k) = toc;
        errs(rw,k) = out.err(end,1);
        iters(rw,k) = out.niter;
        
        x = out.dual;
        fprintf('Relative error is %.2e, and %.2e for out.dualAvg\n',...
            norm(x-x_exact)/norm(x_exact), norm(out.dualAvg-x_exact)/norm(x_exact) );
        
        % continuation update
        xPlug   = x + k/(k+3)*( x - xOld );
        lambda0 = lambda;
        
%         opts.tol = opts.tol/2;
%         opts.tol = opts.tol/1.5
        opts.tol = opts.tol/tol_increase;
        if k > 1
          change = norm( x - xOld )/norm(x);
          fprintf('After continuation %d, rel. change in x is %.2e\n',k,change);
          if change < tol_continuation, disp('Change is small, so exiting from continuation'); break; end
        end
        xOld    = x;
        
        
    end
    
    % update weights
    coeff   = psiT(x);
    cSort   = sort(abs(coeff),'descend');
    ind     = [find( cumsum(cSort.^2)/sum(cSort.^2) > (cutoff_rw  )/100 );length(cSort)];
    fprintf('cutoff index is %d of %d total, i.e. %.4f%%\n', ind(1),length(cSort),...
        100*ind(1)/length(cSort) );
    cutoff  = cSort(ind(1));
    weights = 1./( abs(coeff) + cutoff );
    W       = @(x) weights.*psiT(x);
    Wt      = @(y) psi(weights.*y);
    
    change  = norm( x - xOld_rw)/norm(x);
    fprintf('After reweighting %d, rel. change in x is %.2e\n',rw, change );
    if change < tol_rw, disp('Change is small, so exiting from reweighting'); break; end
    xOld_rw = x;
    xPlug   = x;
    
end
if DANTZIG, type = 'dantzig'; else type = 'bpdn'; end
%save(sprintf('rmpi_results_%s',type),'time','errs','iters');
save(sprintf('rmpi_new_results_%s',type),'time','errs','iters'); % so we don't overwrite the good results
fprintf('TOTAL ELAPSED TIME IS %.1f MINUTES\n', etime(clock,tt)/60 );
%%
DANTZIG = true;
if DANTZIG, type = 'dantzig'; else type = 'bpdn'; end
load(sprintf('rmpi_results_%s',type))
%% make a table showing time and # of iterations
% disp(time)
% disp(errs)
if DANTZIG, type = 'dantzig'; else type = 'bpdn'; end
rw = size(time,1);

fprintf('For %s\n', type);
for rw_i = 1:rw
%     fprintf('%.1f s\t',time(rw_i,:) );
    nCont = length( find(iters(rw_i,:) ) );
    nn = sum(iters(rw_i,: ));
    tm = sum(time(rw_i,:));
    e  = errs(rw_i,nCont);
%     fprintf('%.1e \t',errs(rw_i,:) );
%     nn
%     tm
%     e
    fprintf('Reweight %d, %d continuation steps, %d total iters, %.1f seconds, %.2e final error\n',...
        rw_i, nCont, nn, tm, e );
%     fprintf('\n');
end


%%
figure(1); clf;
% win = chebwin(N);
win = hamming(N);
% win = hann(N);
% win = kaiser(N);
% win = nuttallwin(N);
% win = blackmanharris(N);
% win = [];
NN = 1*N;

% periodogram( x, win, [], FS );
[Pxx,F] = periodogram( x_exact, win, NN, FS );
Pxx = db(Pxx,'power');
F = F/GHz;
plot( F, Pxx,'k','linewidth',2);
hold all

% [Pxx,F] = periodogram( x_noisy, win, NN, FS );
% Pxx = db(Pxx,'power');
% F = F/GHz;
% % plot( F, Pxx,'bo','markersize',10 );
% plot( F, Pxx,'b','linewidth',2 );

[Pxx,F] = periodogram( x, win, NN, FS );
Pxx = db(Pxx,'power');
F = F/GHz;
plot( F, Pxx,'r.','markersize',20 );
% plot( F, Pxx,'r','linewidth',2 );

xlabel('Frequency (GHz)','fontsize',20);
ylabel('Power/frequency (dB/Hz)','fontsize',20);

ylim([-220,-50])

h = legend('Original signal','Recovered signal');
set(h,'fontsize',20 );

%%
figure(3); clf;
plot( x )
