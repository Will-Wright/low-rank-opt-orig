function setup_path_test()
% run this to setup the path for the "paper" tests

p = fileparts(mfilename('fullpath'));
addpath( fullfile(p,'utilities') );