These scripts generate the figures in the paper (with perhaps less formatting...)
TFOCS version 1.0a, code by Michael Grant (mcg@cvxr.com) and Stephen Becker (srbecker@caltech.edu)

Note: as of Oct 13, 2010, this directory is not fully complete

Below is a list of figures and the corresponding code used to generated them

Note: so that figure #'s are consistent, the figure numbers I refer to here are
from the "TFOCS_Oct2010_reference.pdf" copy included in this file (since, e.g.,
a journal version of the paper may be a bit different).

Figure 1: Trivial to generate, so not including code for this.

Figure 2: Exact penalty property for Dantzig Selector. see "ExactPenaltyTest" folder

Figure 3: Accelerated continuation, outer iterations only, on LASSO. see "ContinuationOuter" folder

Figure 4: Accelerated continuation, inner iterations, on Dantzig.  see "ContinuationDantzig" folder

Figure 5: Test on a strongly convex quadratic problem.  see "StronglyConvexQuadratic"

Figure 6: Comparison of gradient descent variants on the Dantzig Selector.  see "CompareFirstOrderSolvers" folder

Figure 7: Comparison of solver vs. SPGL1 on LASSO.  see "CompareWithSPGL1" folder

Figure 8: Wavelet + TV denoising.  see "TV_and_Analysis_denoising" folder

Figure 9: Noiseless matrix completion.  see "MatrixCompletion" folder, and "noiselessMatrixCompletion.m"

Figure 10: Noisy matrix completion.  see "MatrixCompletion" folder, and "nosisyMatrixCompletion.m"

Figure 11: Radar signal via RMPI.  see "RMPI" folder
