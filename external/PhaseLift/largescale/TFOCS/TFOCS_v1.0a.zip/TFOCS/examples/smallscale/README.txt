This directory contains basic tests that have little *scientific*
value, but demonstrate how to use different solvers.

Most of the tests use a stored reference solution (generated
from an interior-point solver) to measure error.

These are generally small-scale tests, designed as a proof-of-concept.
