function v = tfocs_dot( x, y )
% TFOCS_DOT   Dot product <x,y>.  Returns real(x'*y)
%   For matrices, this is the inner product that induces the Frobenius
%   norm, i.e. <x,y> = tr(x'*y), and not matrix multiplication.

% Note: this is real(x'*y) and not real(x.'*y)


% Allow scalar times vector multiplies:
if isscalar(x) && ~isscalar(y)
    if ~x, 
        v = 0; 
        return;
    else
        x = repmat(x,size(y,1),size(y,2) ); % doesn't work if y is a cell
    end
elseif isscalar(y) && ~isscalar(x)
    if ~y
        v = 0;
        return;
    else
        y = repmat(y,size(x,1),size(x,2) );
    end
end


if isempty( x ) || isempty( y ),
    v = 0;
elseif isreal( x ) || isreal( y ),
    if issparse( x ) || issparse( y ),
        v = sum( nonzeros( real(x) .* real(y) ) );
    else
        v = sum( real(x(:))' * real(y(:)) );  % why the "sum" ?
    end
else
    if issparse( x ) || issparse( y ),
        v = sum( nonzeros( real(x) .* real(y) ) ) + ...
            sum( nonzeros( imag(x) .* imag(y) ) );
    else
        v = sum( real(x(:))' * real(y(:)) ) + ...
            sum( imag(x(:))' * imag(y(:)) );
    end
end

% TFOCS v1.0a by Stephen Becker, Emmanuel Candes, and Michael Grant.
% Copyright 2010 California Institute of Technology and CVX Research.
% See the file TFOCS/COPYING.txt for full license information.