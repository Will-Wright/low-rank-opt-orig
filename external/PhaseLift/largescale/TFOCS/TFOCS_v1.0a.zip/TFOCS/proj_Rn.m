function op = proj_Rn

%PROJ_Rn    "Projection" onto the entire space.
%    OP = PROX_0 returns an implementation of the function OP(X) = 0. Use
%    this function to specify a model with no nonsmooth component. It is
%    identical to both PROX_0 and SMOOTH_CONSTANT( 0 ).

op = smooth_constant( 0 );

% TFOCS v1.0a by Stephen Becker, Emmanuel Candes, and Michael Grant.
% Copyright 2010 California Institute of Technology and CVX Research.
% See the file TFOCS/COPYING.txt for full license information.
